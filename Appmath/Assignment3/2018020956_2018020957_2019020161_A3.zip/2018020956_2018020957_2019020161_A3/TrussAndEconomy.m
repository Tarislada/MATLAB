%% Applied Mathematics Assignment 3
% Truss and Economy
% this code utilizes Gauss Elimination to solve truss and
% economy problems
% Authors : Changbum Ko, Soyoung Gill and Haeji Shin
% Created : 2019/04/26

%% initalize
% clear all variables, close all figures, and clear the command window
clear all;
close all;
clc;

%% Begin Assignment (a)
% create a cell containing the six unknown forces F1, F2, F3, H2, V2, and V3.
Forces = {'F1';'F2';'F3';'H2';'V2';'V3'};
% define matrix(Trussmat) and result matrix(Trussres). The equation should
% return the unknown forces.
Trussmat = [-0.866,0,0.5,0,0,0;-0.5,0,-0.866,0,0,0;0.866,1,0,1,0,0;0.5,0,0,0,1,0;0,-1,-0.5,0,0,0;0,0,0.866,0,0,1];
Trussres = [0;-1000;0;0;0;0]; 
[Det, varF] = GaussElimination(Trussmat,Trussres); % execute Gaussian Elimination to get the determinant and solution matrix varF using the function GaussElimination.
% put in the solution for the unknown forces earned from Gaussian
% Elimination.
for f = 1:length(varF)
    Forces{f,2} = varF(f);
end


%% Begin Assignment (b)
% define matrix that solves the economy with three sectors.
% input demand matrix representing the amount of input needed to produce a
% dollar worth of steel, energy, cars per row.
inputD = [0.1,0.65,0.05;0.04,0.2,0.1;0.6,0.2,0.05]; 
% transpose the input demand to create the internal demand matarix,
% represented as M in the problem.
internalD = inputD';
% create a 3 by 3 identity matrix.
I = eye(length(inputD));
% subtract the internal demand matrix from the identity matrix to create
% (I-M) as in (I-M)X=b.
Demand = I - internalD;
finalDemand = [10;15;20]; % the final results of each sector given in the problem as b.
[det,totalOutput] = GaussElimination(Demand,finalDemand); % execute Gauss Elimination to get the product using the function GaussElimination, totalOutput is the total Output X wanted.
%% Additional Questions
% 1) Numbers in (1),(2), and (3) do not add up to 1$ because production
% values do not directly equal the final value.
% 2) Solution X does not add up to the sum of the final demand because the
% matrix b does not equal X; the given equation will be transformed into
% (I-M)X = b.
% 2) Solution X does not add up to the sum of the final demand b because as
% the equation X = MX + b shows X is the sum of the internal demand and
% the final demand, thus much greater than the final demand.