%% Applied Mathematics Assignment 3
% Gauss Elimination
% this code defines Gauss Elimination using pivoting
% Authors : Changbum Ko, Soyoung Gill and Haeji Shin
% Created : 2019/04/26

%% Define the function
function [determinant,variables] = GaussElimination(sqrmat,results)
%% Inital error check
% check for a few errors before starting the code
       if size(sqrmat,1) ~= size(sqrmat,2) % if the dimensions of squrmat are not equal...
           error("The __ is not square"); % print error message
       elseif size(sqrmat,1) ~= size(results,1) % if the size of sqrmat and the results are not equal..
           error("The dimensions of results and matrix does not fit"); % print error message
       end
%% Setup working variables  
       globalsize = size(sqrmat,1);     % A size that will be used often
       workingmat = [sqrmat,results];   % Matrix to work with - combination of the matrix and solution vector
       variables = zeros(globalsize,1); % Preset size of the variables
%% Partial Pivoting       
       for ii = 1:globalsize-1
           [abspivot,pivotindex] = max(abs(workingmat(ii:end,ii)));     % Find pivot index and pivot value
           [abspivotrow, ~] = find(abs(workingmat(:,ii))==abspivot);    % Find pivot row to switch rows
           abspivotrow = abspivotrow(abspivotrow>=ii);                  % to prevent pivot getting set at point behind working column&row
           abspivotrow = abspivotrow(1);                                % to prevent cases where there are multiple pivots
           pivot = workingmat(abspivotrow,ii);                          % Get signed pivot value
           if pivot == 0                                                % Detect error - when the pivot value = 0
               error("This system cannot be solved-leading coefficient = 0");    % print an error message
           else
               workingmat([abspivotrow(1,1) ii],:) = workingmat([ii abspivotrow(1,1)],:);   % Switch rows to put pivotrow on top
               if triu(workingmat) == workingmat                          % Early break - when there is no longer any need to pivot
                   break
               else
%% Forward Elimination                   
                   for sequence = ii:globalsize-1   
                       workingmat(sequence+1,:) = workingmat(sequence+1,:) - (workingmat(ii,:)*(workingmat(sequence+1,ii)/pivot)); 
                       % a
                   end
              end
           end
       end
%% Backword Substitution       
               workingres = workingmat(:,end);          % Re-split workingmatrix into processed solution vector 
               workingmat = workingmat(:,1:end-1);      % and matrix
               variables(globalsize) = workingres(globalsize)/ workingmat(globalsize,globalsize); % Last element of final solution
               for iii = globalsize-1:-1:1                                                        % Work down from the top
                   workingres(1:iii) = workingres(1:iii) - variables(iii+1)*workingmat(1:iii,iii+1);    % step-wise subtraction
                   variables(iii) = workingres(iii)/workingmat(iii,iii);                                % Common divisor (ann)
               end
%% Find Determinant              
               determinant = prod(diag(workingmat));  % Calculating the determinant

%% Interpretation
% because the forward elimination has much more loops, it takes much more
% time than backword substitution